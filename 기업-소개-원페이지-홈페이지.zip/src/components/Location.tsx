import React, { useState } from 'react';
import { CompanyConfig } from '../types';
import { MapPin, Copy, Check, ExternalLink } from 'lucide-react';

interface LocationProps {
  company: CompanyConfig;
}

export const Location: React.FC<LocationProps> = ({ company }) => {
  const [copied, setCopied] = useState(false);
  const [mapZoom, setMapZoom] = useState(1);

  const copyAddress = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(company.address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <section id="location" className="py-20 md:py-28 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header: 설명칸 없이 간결하게 구성 */}
        <div className="max-w-3xl mb-8">
          <div className="text-xs font-semibold text-blue-800 tracking-wider uppercase mb-2">
            오시는 길
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-slate-900">
            회사 정보 및 오시는 길
          </h2>
        </div>

        {/* Map Viewer Container with Integrated Address Display & Copy Button */}
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
          {/* Map Top Header: Address & Copy Action Bar */}
          <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-800 flex items-center justify-center shrink-0">
                <MapPin className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  회사 위치 주소
                </span>
                <span className="text-sm sm:text-base font-bold text-slate-900 truncate block">
                  {company.address}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
              {/* Address Copy Button */}
              <button
                type="button"
                onClick={copyAddress}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 rounded-lg transition-colors cursor-pointer"
                title="주소 클립보드 복사"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-700">주소 복사됨</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-500" />
                    <span>주소 복사</span>
                  </>
                )}
              </button>

              {/* Zoom Controls */}
              <div className="flex items-center gap-1 border-l border-slate-200 pl-2">
                <button
                  type="button"
                  onClick={() => setMapZoom(Math.max(0.8, mapZoom - 0.2))}
                  className="w-7 h-7 flex items-center justify-center bg-slate-100 hover:bg-slate-200 rounded-md text-slate-700 transition-colors font-bold text-xs"
                  title="지도 축소"
                >
                  -
                </button>
                <button
                  type="button"
                  onClick={() => setMapZoom(Math.min(1.4, mapZoom + 0.2))}
                  className="w-7 h-7 flex items-center justify-center bg-slate-100 hover:bg-slate-200 rounded-md text-slate-700 transition-colors font-bold text-xs"
                  title="지도 확대"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* Stylized Vector Map Canvas */}
          <div className="relative h-80 sm:h-96 md:h-[420px] w-full bg-slate-100 overflow-hidden select-none">
            <div
              className="absolute inset-0 transition-transform duration-300 ease-out"
              style={{ transform: `scale(${mapZoom})`, transformOrigin: 'center center' }}
            >
              {/* SVG Map Layout Lines */}
              <svg className="w-full h-full opacity-60" viewBox="0 0 800 500" preserveAspectRatio="none">
                <rect x="0" y="0" width="800" height="500" fill="#f8fafc" />
                <path d="M 0 350 Q 250 320 500 370 T 800 340 L 800 500 L 0 500 Z" fill="#e2e8f0" />

                <line x1="0" y1="180" x2="800" y2="180" stroke="#cbd5e1" strokeWidth="12" />
                <line x1="0" y1="180" x2="800" y2="180" stroke="#ffffff" strokeWidth="8" />

                <line x1="400" y1="0" x2="400" y2="500" stroke="#cbd5e1" strokeWidth="12" />
                <line x1="400" y1="0" x2="400" y2="500" stroke="#ffffff" strokeWidth="8" />

                <line x1="120" y1="0" x2="680" y2="500" stroke="#cbd5e1" strokeWidth="8" />
                <line x1="120" y1="0" x2="680" y2="500" stroke="#f1f5f9" strokeWidth="4" />

                <rect x="180" y="60" width="160" height="90" rx="4" fill="#f1f5f9" stroke="#e2e8f0" />
                <rect x="440" y="60" width="220" height="90" rx="4" fill="#f1f5f9" stroke="#e2e8f0" />
                <rect x="180" y="210" width="180" height="110" rx="4" fill="#f1f5f9" stroke="#e2e8f0" />
                <rect x="440" y="210" width="220" height="110" rx="4" fill="#f1f5f9" stroke="#e2e8f0" />
              </svg>

              {/* Center Location Pin Marker */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
                <div className="px-3.5 py-1.5 bg-slate-900 text-white rounded-lg shadow-lg text-xs font-bold flex items-center gap-1.5 whitespace-nowrap mb-1">
                  <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                  <span>{company.name} 본사</span>
                </div>
                <div className="w-9 h-9 rounded-full bg-blue-900 text-white flex items-center justify-center shadow-lg border-2 border-white">
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="w-2 h-2 bg-slate-400 rounded-full blur-[1px] mt-0.5" />
              </div>
            </div>

            {/* Map Bottom Bar with External Navigation Links (주소칸 삭제, 네이버/카카오 지도 버튼 유지) */}
            <div className="absolute bottom-3 right-3 flex items-center gap-2 bg-white/95 backdrop-blur-xs p-2 rounded-xl border border-slate-200 text-xs shadow-xs">
              <a
                href="https://map.naver.com"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-lg transition-colors text-xs font-semibold border border-slate-200"
              >
                <span>네이버 지도</span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
              <a
                href="https://map.kakao.com"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-800 rounded-lg transition-colors text-xs font-semibold border border-slate-200"
              >
                <span>카카오맵</span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
